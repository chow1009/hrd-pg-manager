REPLACE THE EXISTING GITHUB PAGES index.html WITH THIS ONE.

This V4 is intentionally a single static HTML file. It contains all 265 tenant records directly in the page, so it does not depend on data.js, app.js, or a separate cache.

After uploading, open:
https://chow1009.github.io/hrd-pg-manager/?v=15sep4

If the browser still shows an old page, use an Incognito window or clear site data for chow1009.github.io.
